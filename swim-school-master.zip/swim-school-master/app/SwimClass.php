<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SwimClass extends Model
{
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'day', 'time', 'venue_id', 'age_group', 'level', 'fee', 'fee_type'
    ];

    public function venue(){
        return $this->belongsTo('App\Venue');
    }
}
