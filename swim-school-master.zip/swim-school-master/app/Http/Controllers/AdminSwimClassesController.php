<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Venue;
use App\SwimClass;
use App\Http\Requests\SwimClassRequest;

class AdminSwimClassesController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $classes = SwimClass::paginate(10);   
        return view('admin.classes.index', compact('classes'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $venues = Venue::pluck('venue_name','id')->all();
        $ageGroups = array('Kids' => 'Kids', 'Adult' => 'Adult');
        $levels = array('Beginner' => 'Beginner', 'Swimmer' => 'Swimmer');
        $feeTypes = array('per week' => 'per week', 'per month' => 'per month', 'per year' => 'per year');
        
        return view('admin.classes.create', compact('venues', 'ageGroups', 'feeTypes', 'levels'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(SwimClassRequest $request)
    {
        SwimClass::create($request->all());
        return redirect('admin/classes');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $venues = Venue::pluck('venue_name','id')->all();
        $ageGroups = array('Kids' => 'Kids', 'Adult' => 'Adult');
        $levels = array('Beginner' => 'Beginner', 'Swimmer' => 'Swimmer');
        $feeTypes = array('per week' => 'per week', 'per month' => 'per month', 'per year' => 'per year');
        $swim_class = SwimClass::find($id);
        
        return view('admin.classes.edit', compact('venues', 'ageGroups', 'feeTypes', 'levels', 'swim_class'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(SwimClassRequest $request, $id)
    {
        $swim_class = SwimClass::find($id);

        $swim_class->day = $request->input('day');
        $swim_class->time = $request->input('time');
        $swim_class->venue_id = $request->input('venue_id');
        $swim_class->age_group = $request->input('age_group');
        $swim_class->save();
        return redirect('admin/classes')->with('status', 'Class updated!');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        SwimClass::findOrFail($id)->delete();
        return redirect('admin/classes')->with('status', 'Class deleted successfully!');
    }
}
