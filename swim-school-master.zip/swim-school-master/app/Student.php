<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Student extends Model
{
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'name', 'ic_number', 'dob', 'description', 'class_id', 'contact_no'
    ];

    public function swim_class(){
        return $this->belongsTo('App\SwimClass');
    }
}
