<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');

Route::get('/admin',function(){
	return view('admin.index');
})->middleware('auth');

Route::resource('admin/users','AdminUsersController')->middleware('auth');
Route::resource('admin/students','AdminStudentsController')->middleware('auth');
Route::resource('admin/classes','AdminSwimClassesController')->middleware('auth');
Route::resource('admin/coaches','AdminCoachesController')->middleware('auth');
Route::resource('admin/awards','AdminAwardsController')->middleware('auth');
Route::resource('admin/sms','AdminSmsController')->middleware('auth');
Route::resource('admin/payments','AdminPaymentsController')->middleware('auth');
Route::resource('admin/venues','AdminVenuesController')->middleware('auth');
