<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateSwimClassesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('swim_classes', function (Blueprint $table) {
            $table->increments('id');
            $table->string('day');
            $table->string('time');
            $table->integer('venue_id')->unsigned();
            $table->string('age_group');
            $table->string('level');
            $table->string('fee');
            $table->string('fee_type');
            $table->foreign('venue_id')->references('id')->on('venues');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('swim_classes');
    }
}
