@extends('layouts.admin')

@section('content')

<h1>Awards</h1>



@stop