@extends('layouts.admin')

@section('content')

<!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Classes
      </h1>
      <ol class="breadcrumb">
        <li><a href="{{url('admin')}}"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Classes</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
    	<div class="box">
            <div class="box-header">
              <p> <a href = "{{url('admin/classes/create')}}" class="btn btn-success"> + Create Class </a></p>
            </div>
            <!-- /.box-header -->
            <div class="box-body table-responsive no-padding">
            	@if (session('status'))
				    <div class="alert alert-info">
				        {{ session('status') }}
				    </div>
				@endif
               <table class="table table-striped">
				    <thead>
				      <tr>
				        <th>Id</th>
				        <th>Day</th>
				        <th>Time</th>
				        <th>Venue</th>
				        <th>Age Group</th>
				        <th>Level</th>
				        <th>Fee</th>
				        <th>Fee Type</th>
				        <th colspan = "2">Actions</th>
				      </tr>
				    </thead>
				    <tbody>
				      @if($classes)

				      @foreach($classes as $class)
				      <tr>
				        <td>{{$class->id}}</td>
				        <td>{{$class->day}}</td>
				        <td>{{$class->time}}</td>
				        <td>{{$class->venue->venue_name}}</td>
				        <td>{{$class->age_group}}</td>
				        <td>{{$class->level}}</td>
				        <td>{{$class->fee}}</td>
				        <td>{{$class->fee_type}}</td>
				        <td>
				        	<a href="{{url("admin/classes/$class->id/edit")}}" title = "Edit" class="btn btn-primary">Edit</a>
				        </td>
				        <td>	
				        	{!! Form::open(['method' => 'DELETE', 'route' => ['classes.destroy', $class->id]]) !!}
                            {{ Form::submit('Delete', ['class' => 'btn btn-danger']) }}
				        	{!! Form::close() !!}
				        	
				        </td>
				      </tr>
				      @endforeach
				      @endif
				      
				    </tbody>
				</table>

				{{ $classes->links() }}
            </div>
        </div>
    </section>        

@stop