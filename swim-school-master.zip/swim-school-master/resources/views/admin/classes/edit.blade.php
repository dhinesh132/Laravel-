@extends('layouts.admin')

@section('content')

<!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Update Class
      </h1>
      <ol class="breadcrumb">
        <li><a href="{{url('admin')}}"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Classes</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
    	<div class="box">
            <div class="box-header">
              <h3 class="box-title">Please fill the form below to create a class!</h3>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
            <form method="post"	action="{!! action('AdminSwimClassesController@update', ['id' => $swim_class->id]) !!}" >

            {!! Form::model($swim_class,['method' =>'PATCH','action' => ['AdminSwimClassesController@update',$swim_class->id]]) !!}
              
              <div class = "row">
              <div class = "col-xs-6">
                <div class = "form-group">
                {{ Form::label('day', 'Day:') }}
                {{ Form::select('day', array(''=>'-- Select Day--', 'Sun' =>'Sunday', 'Mon' =>'Monday', 'Tue' =>'Tuesday', 'Wed' =>'Wednesday', 'Thu' =>'Thursday', 'Fri' =>'Friday', 'Sat' =>'Saturday'), $swim_class->day, ['class'=>'form-control', 'required' => true]) }}
                </div>
              </div> 
              <div class = "col-xs-6">
                <div class = "form-group">
                {{ Form::label('time', 'Time:') }}
                {{ Form::select('time', array(''=>'-- Select Time--', '01 AM'=>'01 AM', '02 AM'=>'02 AM', '03 AM'=>'03 AM', '04 AM'=>'04 AM', '05 AM'=>'05 AM', '06 AM'=>'06 AM', '07 AM'=>'07 AM', '08 AM'=>'08 AM', '09 AM'=>'09 AM', '10 AM'=>'10 AM', '11 AM'=>'11 AM', '12 PM'=>'12 PM', '01 PM'=>'01 PM' , '02 PM'=>'02 PM', '03 PM'=>'03 PM', '04 PM'=>'04 PM', '05 PM'=>'05 PM', '06 PM'=>'06 PM'), $swim_class->time, ['class'=>'form-control', 'required' => true]) }}
                </div>
              </div>  
              <div class = "col-xs-6">
              <div class = "form-group">
              {{ Form::label('venue_id', 'Venue:') }}
              {{ Form::select('venue_id', ['' => '--Select Venue--'] + $venues, $swim_class->venue->id, ['class'=>'form-control']) }}
              </div>
              </div>
              <div class = "col-xs-6">
              <div class = "form-group">
              {{ Form::label('age_group', 'Age Group:') }}
              {{ Form::select('age_group', ['' => '--Select Age Group--'] + $ageGroups, $swim_class->age_group, ['class'=>'form-control']) }}
              </div>
              </div>
              <div class = "col-xs-6">
              <div class = "form-group">
              {{ Form::label('level', 'Level:') }}
              {{ Form::select('level', ['' => '--Select Level--'] + $levels, $swim_class->level, ['class'=>'form-control']) }}
              </div>
              </div>
              <div class = "col-xs-6">
              <div class = "form-group">
              {{ Form::label('fee', 'Fee:') }}
              {{ Form::text('fee', $swim_class->fee, ['class'=>'form-control','placeholder' => 'Enter Fee']) }}
              </div>
              </div>
              <div class = "col-xs-6">
              <div class = "form-group">
              {{ Form::label('fee_type', 'Fee Type:') }}
              {{ Form::select('fee_type', ['' => '--Select Fee Type--'] + $feeTypes, $swim_class->fee_type, ['class'=>'form-control']) }}
              </div>
              </div>
            </div>

            <div class = "form-group">
              {{ Form::submit('Update Class', ['class'=>'btn btn-primary']) }}
            </div>  
               {!! Form::close() !!}
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
    </section>	
@stop