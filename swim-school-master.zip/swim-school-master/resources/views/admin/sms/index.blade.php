@extends('layouts.admin')

@section('content')

<h1>SMS</h1>



@stop