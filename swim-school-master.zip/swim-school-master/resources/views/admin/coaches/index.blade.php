@extends('layouts.admin')

@section('content')

<h1>Coaches</h1>



@stop