@extends('layouts.admin')

@section('content')

<h1>Payments</h1>



@stop