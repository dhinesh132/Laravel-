@extends('layouts.admin')

@section('content')

<!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Venues
      </h1>
      <ol class="breadcrumb">
        <li><a href="{{url('admin')}}"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Venues</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="box">
            <div class="box-header">
              <p> <a href = "{{url('admin/venues/create')}}" class="btn btn-success"> + Create Venue </a></p>
            </div>
            <!-- /.box-header -->
            <div class="box-body table-responsive no-padding">
              @if (session('status'))
            <div class="alert alert-info">
                {{ session('status') }}
            </div>
        @endif
               <table class="table table-striped">
            <thead>
              <tr>
                <th>Id</th>
                <th>Name</th>
                <th>Address</th>
                <th colspan = "2" width="4%">Actions</th>
              </tr>
            </thead>
            <tbody>
              @if($venues)

              @foreach($venues as $venue)
              <tr>
                <td>{{$venue->id}}</td>
                <td>{{$venue->venue_name}}</td>
                <td>{{$venue->venue_address}}</td>
                <td>
                  <a href="{{url("admin/venues/$venue->id/edit")}}" title = "Edit" class="btn btn-primary">Edit</a>
                </td>
                <td>  
                  {!! Form::open(['method' => 'DELETE', 'route' => ['venues.destroy', $venue->id]]) !!}
                            {{ Form::submit('Delete', ['class' => 'btn btn-danger']) }}
                  {!! Form::close() !!}
                  
                </td>
              </tr>
              @endforeach
              @endif
              
            </tbody>
        </table>

        {{ $venues->links() }}
            </div>
        </div>
    </section>        

@endsection