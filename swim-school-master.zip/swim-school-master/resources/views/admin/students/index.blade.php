@extends('layouts.admin')

@section('content')

<!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Students
      </h1>
      <ol class="breadcrumb">
        <li><a href="{{url('admin')}}"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Students</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="box">
            <div class="box-header">
              <p> <a href = "{{url('admin/students/create')}}" class="btn btn-success"> + Create Student </a></p>
            </div>
            <!-- /.box-header -->
            <div class="box-body table-responsive no-padding">
              @if (session('status'))
            <div class="alert alert-info">
                {{ session('status') }}
            </div>
        @endif
               <table class="table table-striped">
            <thead>
              <tr>
                <th>Id</th>
                <th>Name</th>
                <th>IC Number</th>
                <th>Date of birth</th>
                <th>Join Date</th>
                <th>Contact Number</th>
                <th>Description</th>
                <th colspan = "2">Actions</th>
              </tr>
            </thead>
            <tbody>
              @if($students)

              @foreach($students as $student)
              <tr>
                <td>{{$student->id}}</td>
                <td>{{$student->name}}</td>
                <td>{{$student->ic_number}}</td>
                <td>{{$student->dob}}</td>
                <td>{{$student->created_at}}</td>
                <td>{{$student->description}}</td>
                <td>
                  <a href="{{url("admin/students/$student->id/edit")}}" title = "Edit" class="btn btn-primary">Edit</a>
                </td>
                <td>  
                  {!! Form::open(['method' => 'DELETE', 'route' => ['students.destroy', $student->id]]) !!}
                            {{ Form::submit('Delete', ['class' => 'btn btn-danger']) }}
                  {!! Form::close() !!}
                  
                </td>
              </tr>
              @endforeach
              @endif
              
            </tbody>
        </table>

        {{ $students->links() }}
            </div>
        </div>
    </section>        

@endsection