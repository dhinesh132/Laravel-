@extends('layouts.admin')

@section('content')

<!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Create Student
      </h1>
      <ol class="breadcrumb">
        <li><a href="{{url('admin')}}"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Students</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="box">
            <div class="box-header">
              <h3 class="box-title">Please fill the form below to create a student!</h3>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
              @if ($errors->any())
                  <div class="alert alert-danger">
                      <ul>
                          @foreach ($errors->all() as $error)
                              <li>{{ $error }}</li>
                          @endforeach
                      </ul>
                  </div>
              @endif
              {!! Form::open(['method' => 'POST', 'action' => 'AdminStudentsController@store', 'files' => false]) !!}
              <div class = "row">
               
              <div class = "col-xs-6">
              <div class = "form-group">
              {{ Form::label('name', 'Student Name:') }}
              {{ Form::text('name', null, ['class'=>'form-control','placeholder' => 'Enter Student Name']) }}
              </div>
              </div>

              <div class = "col-xs-6">
              <div class = "form-group">
              {{ Form::label('ic_number', 'Student IC Number:') }}
              {{ Form::text('ic_number', null, ['class'=>'form-control','placeholder' => 'Enter Student IC Number']) }}
              </div>
              </div>

              <div class = "col-xs-6">
              <div class = "form-group">
              {{ Form::label('dob', 'Date Of Birth:') }}
              {{ Form::date('dob', null, ['class'=>'form-control']) }}
              </div>
              </div>

              <div class = "col-xs-6">
              <div class = "form-group">
              {{ Form::label('contact_no', 'Contact No:') }}
              {{ Form::text('contact_no', null, ['class'=>'form-control','placeholder' => 'Enter Contact No:']) }}
              </div>
              </div>

              <div class = "col-xs-6">
              <div class = "form-group">
              {{ Form::label('description', 'Description:') }}
              {{ Form::textarea('description', null, ['class'=>'form-control','placeholder' => 'Enter Description:']) }}
              </div>
              </div>
              
            </div>

            <div class = "form-group">
              {{ Form::submit('Create Student', ['class'=>'btn btn-primary']) }}
            </div>  
              {!! Form::close() !!}
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
    </section>  
@stop