@extends('layouts.admin')

@section('content')

<h1>Users</h1>



@stop